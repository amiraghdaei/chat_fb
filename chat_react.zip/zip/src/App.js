import './App.css';
import React from "react";
import LoginAndSignUp from './components/LoginAndSignUp'
import ChatListRow from "./components/ChatListRow";
import ChatList from "./components/ChatList";
import ChatPage from "./components/ChatPage";

class App extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            select_page: 'authentication'
        }
    }
    change_select_page_status = (new_status) => {
        if (this.state.select_page !== new_status){
            this.setState({
                select_page: new_status
            })
        }
    }
    render() {
        return (
            <div
                className="flex min-h-full flex-col justify-center px-6 py-12 items-center fixed w-full h-full">
                {this.state.select_page === 'authentication' ? <LoginAndSignUp changeStatus={this.change_select_page_status} /> : ''}
                {this.state.select_page === 'chat_list' ? <ChatList changeStatus={this.change_select_page_status} /> : ''}
                {this.state.select_page === 'chat_page' ? <ChatPage changeStatus={this.change_select_page_status} /> : ''}
            </div>
        );
    }
}

export default App;
