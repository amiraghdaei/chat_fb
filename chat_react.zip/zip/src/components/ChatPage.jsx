import React from "react";
import MeMessageBox from "./MeMessageBox";
import OtherMessageBox from "./OtherMessageBox";

export default class ChatPage extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            messages: [
                {
                    'writer': 'ali',
                    'content': 'سلام سلام'
                },
                {
                    'writer': 'alimorad',
                    'content': 'سلام خوبید'
                }, {
                    'writer': 'ali',
                    'content': 'ممنون تو خوبی'
                }, {
                    'writer': 'ali',
                    'content': 'امروز هستید ؟'
                },
            ],
            input_value: ''
        }
    }

    componentDidMount() {
    }

    newMessage = (value) => {
        this.setState({
            ...this.state.messages,
            input_value: value
        })
    }

    sendMessage = () => {
        let messages = this.state.messages.slice()
        messages.push({
            'writer': 'ali',
            'content': this.state.input_value
        })

        this.setState({
            messages: messages,
            input_value: ''
        })

    }

    render() {
        const chatElements = this.state.messages.map(value => {
            if (value.writer === 'ali') {
                return <MeMessageBox message={value.content}/>
            }
            return <OtherMessageBox message={value.content}/>
        })
        return <>
            <div className="max-[640px]:mx-auto max-[640px]:w-full w-80 max-[640px]:max-w-sm flex flex-col items-center">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5"
                     stroke="currentColor"
                     className="w-8 h-8">
                    <path strokeLinecap="round" strokeLinejoin="round"
                          d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m.94 3.198l.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0112 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 016 18.719m12 0a5.971 5.971 0 00-.941-3.197m0 0A5.995 5.995 0 0012 12.75a5.995 5.995 0 00-5.058 2.772m0 0a3 3 0 00-4.681 2.72 8.986 8.986 0 003.74.477m.94-3.197a5.971 5.971 0 00-.94 3.197M15 6.75a3 3 0 11-6 0 3 3 0 016 0zm6 3a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0zm-13.5 0a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0z"/>
                </svg>

            </div>
            <div className="flex flex-row justify-between items-center max-[640px]:mx-auto max-[640px]:w-full w-80 max-[640px]:max-w-sm mt-4">
                <span className="text-lg font-semibold">برادران عزیز</span>
                <svg onClick={() => {
                    this.props.changeStatus('chat_list')
                }} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5"
                     stroke="currentColor" className="w-7 h-7 p-1.5 bg-gray-200 rounded-full">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 15L3 9m0 0l6-6M3 9h12a6 6 0 010 12h-3"/>
                </svg>
            </div>
            <div className="flex flex-col max-[640px]:mx-auto max-[640px]:w-full w-80 max-[640px]:max-w-sm rounded-lg h-full mt-2 bg-gray-50">
                <div className="w-full h-full overflow-y-auto flex flex-col">
                    {chatElements}

                </div>

            </div>
            <form className="max-[640px]:mx-auto max-[640px]:w-full w-80 max-[640px]:max-w-sm flex flex-col items-center">
                <label htmlFor="chat" className="sr-only">پیام ...</label>
                <div className="flex items-center py-2 px-2 gap-1 rounded-lg bg-gray-50 dark:bg-gray-700 w-full">
                <textarea id="chat" rows="1" value={this.state.input_value} onChange={(e) => {
                    this.newMessage(e.target.value)
                }}
                          className="block p-2.5 w-full text-sm text-gray-900 bg-white rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-800 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                          placeholder="پیام ...">

                </textarea>
                    <button type="button" onClick={() => {this.sendMessage()}}
                            className="inline-flex justify-center p-2 text-blue-600 rounded-full cursor-pointer hover:bg-blue-100 dark:text-blue-500 dark:hover:bg-gray-600">
                        <svg className="svg_rotate w-5 h-5 rotate-90" aria-hidden="true"
                             xmlns="http://www.w3.org/2000/svg"
                             fill="currentColor"
                             viewBox="0 0 18 20">
                            <path
                                d="m17.914 18.594-8-18a1 1 0 0 0-1.828 0l-8 18a1 1 0 0 0 1.157 1.376L8 18.281V9a1 1 0 0 1 2 0v9.281l6.758 1.689a1 1 0 0 0 1.156-1.376Z"/>
                        </svg>
                        <span className="sr-only">Send message</span>
                    </button>
                </div>
            </form>
        </>
    }
}