import React from "react";
import ChatListRow from "./ChatListRow";

export default class ChatList extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            groups: [
                {
                    title: 'برادران عزیز',
                    hide: false
                },
                {
                    title: 'یک گروه',
                    hide: false
                },
                {
                    title: 'گروه تستی',
                    hide: false
                }
            ]
        }
    }

    componentDidMount() {

    }

    deleteGroup = (index) => {
        let groups = this.state.groups.slice()
        groups[index].hide = true
        this.setState({
            groups
        })
    }

    render() {
        const groupElements = this.state.groups.map((value, index) => {
            return !value.hide?<ChatListRow title={value.title} deleteGroup={this.deleteGroup} index={index} change_status={this.props.changeStatus}/>:''
        })
        return <div className="flex flex-col w-full items-center gap-4">
            <div className="sm:mx-auto sm:w-full sm:max-w-sm">
                <img className="mx-auto h-8 w-auto rounded-lg"
                     src="https://cdn.britannica.com/22/1722-004-EAD033D8/Flag-Iran.jpg"
                     alt="Your Company"/>
            </div>
            <span className="text-lg font-semibold">گفت و گوی گروهی</span>
            <div
                className="mt-24 flex flex-col max-[640px]:mx-auto max-[640px]:w-full w-80 max-[640px]:max-w-sm border-2 border-gray-400 rounded-lg border-b-0">

                {groupElements}
            </div>
        </div>
    }
}