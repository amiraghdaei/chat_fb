from channels.consumer import SyncConsumer, AsyncConsumer
from channels.exceptions import StopConsumer
import json
from channels.db import database_sync_to_async
from urllib import parse as urlparse
from .models import GroupChat, User, Member


class ChatConsumer(AsyncConsumer):
    async def websocket_connect(self, event):
        query = self.scope['query_string']
        query_string = urlparse.parse_qs(query.decode('UTF-8'))

        username = query_string.get('username', [None])[0]
        password = query_string.get('password', [None])[0]

        if not (username and password):
            raise StopConsumer()

        auth_user = User.objects.filter(username=username)

        pass_auth_user = False

        if auth_user.exists():
            auth_user = auth_user[0]

            pass_auth_user = auth_user.check_password(password)

        if pass_auth_user:
            self.user = auth_user

        else:
            raise StopConsumer()

        self.chat_id = self.scope['url_route']['kwargs']['chat_id']

        self.chat = await self.get_chat()

        if self.chat:
            await self.user_join_group_chat()

            await self.channel_layer.group_add(
                self.chat_room_id,
                self.channel_name
            )

            await self.send({
                'type': 'websocket.accept'
            })
        else:
            await self.send({
                'type': 'websocket.close'
            })

    async def websocket_disconnect(self, event):
        await self.channel_layer.group_discard(
            self.chat_room_id,
            self.channel_name
        )
        raise StopConsumer()

    async def websocket_receive(self, event):
        text_data = event.get('text', None)
        bytes_data = event.get('bytes', None)

        if text_data:
            text_data_json = json.loads(text_data)
            text = text_data_json['text']

            await self.create_message(text)

            await self.channel_layer.group_send(
                self.chat_room_id,
                {
                    'type': 'chat_message',
                    'message': json.dumps({'type': "msg", 'sender': self.user.username, 'text': text}),
                    'sender_channel_name': self.channel_name
                }
            )

    @database_sync_to_async
    def user_join_group_chat(self, event=None):
        if not Member.objects.filter(chat_id=self.chat.id, user_id=self.user.id).exists():
            Member.objects.create(chat_id=self.chat.id, user_id=self.user.id)

    async def chat_message(self, event):
        message = event['message']

        if self.channel_name != event['sender_channel_name']:
            await self.send({
                'type': 'websocket.send',
                'text': message
            })

    async def chat_activity(self, event):
        message = event['message']

        await self.send({
            'type': 'websocket.send',
            'text': message
        })

    @database_sync_to_async
    def get_chat(self):
        try:
            chat = GroupChat.objects.get(unique_code=self.chat_id)
            return chat
        except GroupChat.DoesNotExist:
            return None
