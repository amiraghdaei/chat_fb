export default function MeMessageBox(props){
    return <div
        className="w-max ml-auto break-all mt-2 mb-1 p-2 rounded-br-none bg-blue-500 rounded-2xl text-gray-100 text-left mr-5 text-sm">
        {props.message}
    </div>
}