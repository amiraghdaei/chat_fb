from django.shortcuts import render
from rest_framework.generics import ListAPIView
from .serializers import GroupChatBaseSerializer
from .models import GroupChat, User


# Create your views here.

class GetAllGroupChat(ListAPIView):
    serializer_class = GroupChatBaseSerializer

    def get_queryset(self):
        username = self.request.GET['username']
        password = self.request.GET['password']
        if not (username and password):
            raise Exception()

        auth_user = User.objects.filter(username=username)

        pass_auth_user = False

        if auth_user.exists():
            auth_user = auth_user[0]

            pass_auth_user = auth_user.check_password(password)

        if pass_auth_user:

            return GroupChat.objects.filter(group_chat_set__user=auth_user)
