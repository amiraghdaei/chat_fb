from django.urls import path
from . import views

urlpatterns = [
    path('get_all_my_chats/', views.GetAllGroupChat.as_view(), name='get_all_group_chats')
]
