from rest_framework.serializers import ModelSerializer
from .models import GroupChat, User, Member


class UserBaseSerializer(ModelSerializer):
    class Meta:
        model = User
        fields = ['username']


class MemberBaseSerializer(ModelSerializer):
    user = UserBaseSerializer(read_only=True)

    class Meta:
        model = Member
        fields = ['user']


class GroupChatBaseSerializer(ModelSerializer):
    group_chat_set = MemberBaseSerializer(many=True, read_only=True)
    creator = UserBaseSerializer(read_only=True)

    class Meta:
        model = GroupChat
        fields = ['group_chat_set', 'title', 'unique_code', 'creator']
